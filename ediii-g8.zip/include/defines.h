/**
 * Grupo 8
 * João Pedro Gomes - 13839069
 * Luana Hartmann Franco da Cruz - 13676350
*/
#define TAM_REGISTRO 76
#define TAM_REGISTRO_FIXO 21
#define TAM_CABECALHO 13
#define TAM_MAXIMO_STRING (TAM_REGISTRO - TAM_REGISTRO_FIXO)
#define LIXO '$'
#define NAO_REMOVIDO '0'
#define REMOVIDO '1'
#define CONSISTENTE '1'
#define INCONSISTENTE '0'