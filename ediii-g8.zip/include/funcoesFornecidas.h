/**
 * Grupo 8
 * João Pedro Gomes - 13839069
 * Luana Hartmann Franco da Cruz - 13676350
*/
void readline(char* string);
void scan_quote_string(char *str);
void binarioNaTela(char *nomeArquivoBinario);