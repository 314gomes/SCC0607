/**
 * Grupo 8
 * João Pedro Gomes - 13839069
 * Luana Hartmann Franco da Cruz - 13676350
*/
#include "parser.h"

int main() {
    tratar_comando_entrada();
    return 0;
}
